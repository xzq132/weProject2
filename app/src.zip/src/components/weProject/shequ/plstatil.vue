<template>
  <div>
    <!-- 头部导航 -->
    <div class="home" >
      <img src="../../../assets/pl.jpg" alt />
      <div>
        <img src="../../../assets/pl.jpg" alt />
        <img src="../../../assets/pl.jpg" alt />
      </div>
    </div>
    <img src="../../../assets/pinglun/kf3.jpg" alt="">
    <img src="../../../assets/pinglun/kf3.jpg" alt="">
    <img src="../../../assets/pinglun/kf3.jpg" alt="">
    <img src="../../../assets/pinglun/kf3.jpg" alt="">
  </div>
</template>
<script>
export default {
  data() {
    return {
      
    }
  },
  methods: {
     handleScroll(){
      var scrollTop=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop;
      // var header=document.getElementsByClassName("home");
      console.log(scrollTop)
      if(scrollTop>40){
        this.searchBar=1;
        // header.style.opacity="1";
      }else{
        this.searchBar=0;
        // header.style.opacity="0";
      }
    }
  },
  mounted() {
    //监听滚动事件
    window.addEventListener('scroll',this.handleScroll)
  },
   
}
</script>
<style lang="scss" scoped>
   // 头部tar
   .home{
     display: flex;
     justify-content: space-between;
     margin: 15px;
     img{
       width: 40px;
       border-radius: 50%;
     }
     
   }
</style>